#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <assert.h>

#include "stack.h"
#include "calculator.h"


static ExprTreeNode *build_expr_tree(Stack *stack, int argc, char **argv) {
    for (size_t i = 1; i < argc; i++) {
        if (strlen(argv[i]) == 1 && (argv[i][0] == '+' || argv[i][0] == '-' ||
                                     argv[i][0] == '*' || argv[i][0] == '/')) {
            // We are dealing with an operator
            if (stack->sz < 2) {
                printf("Insufficient numbers on the stack!\n");
                goto err;
            }

            ExprTreeNode *node = malloc(sizeof(ExprTreeNode));
            assert(node);

            node->op = argv[i][0];
            ExprTreeNode *right = stackPop(stack), *left = stackPop(stack);
            node->left = left;
            node->right = right;

            if (!stackPush(stack, node)) {
                printf("Out of memory\n");
                goto err;
            }
        } else {
            char *end;
            double num = strtod(argv[i], &end);
            if (argv[i] == end || *end != '\0') {
                printf("Failed to parse number \"%s\"\n", argv[i]);
                goto err;
            }

            ExprTreeNode *node = malloc(sizeof(ExprTreeNode));
            assert(node);
            node->val = num;
            node->left = NULL;
            node->right = NULL;

            if (!stackPush(stack, node)) {
                printf("Out of memory\n");
                goto err;
            }
        }
    }

    if (stack->sz != 1) {
        printf("Stack has zero or multiple values remaining!\n");
        goto err;
    }

    ExprTreeNode *root = stackPop(stack);
    return root;

err:
    while (stack->sz) {
        free(stackPop(stack));
    }
    return NULL;
}

void print_expr_tree_node(ExprTreeNode *node, size_t depth) {
    if (!node) return;

    print_expr_tree_node(node->right, depth + 1);
    for (size_t i = 0; i < depth; i++) {
        printf("    ");
    }

    if (node->left || node->right) {
        printf("%c\n", node->op);
    } else {
        printf("%.1f\n", node->val);
    }

    print_expr_tree_node(node->left, depth + 1);
}


void print_expr_tree(ExprTreeNode *tree) {
    puts("-----------------------------");
    print_expr_tree_node(tree, 0);
    puts("-----------------------------");
}

double eval_expr_tree(ExprTreeNode *tree) {
    if (!tree) return 0.0;

    if (!tree->left && !tree->right) {
        // this is an operand node
        return tree->val;
    } else {
        // this is an operator node
        double left_v = eval_expr_tree(tree->left);
        double right_v = eval_expr_tree(tree->right);
        switch (tree->op) {
            case '+': return left_v + right_v;
            case '-': return left_v - right_v;
            case '*': return left_v * right_v;
            case '/': return left_v / right_v;
            default:
                assert(false);
        }
    }
}


int do_calculation(Stack *stack, int argc, char **argv) {
    ExprTreeNode *tree = build_expr_tree(stack, argc, argv);
    if (!tree) return 1;

    print_expr_tree(tree);
    printf("Result=%f\n", eval_expr_tree(tree));

    return 0;
}
