#include "stack.h"
#include "calculator.h"

int main(int argc, char **argv) {
    if (argc < 2) return 1;

    Stack *stack = stackAlloc();
    if (!stack) {
        printf("Out of memory!\n");
        return 1;
    }

    int ret = do_calculation(stack, argc, argv);

    stackFree(stack);
    return ret;
}
