#pragma once

#include "stack.h"

int do_calculation(Stack *stack, int argc, char **argv);

typedef struct ExprTreeNode {
    double val;
    char op;
    struct ExprTreeNode *left, *right;
} ExprTreeNode;
