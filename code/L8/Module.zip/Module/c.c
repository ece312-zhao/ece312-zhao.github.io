#include "b.h"

int subtract_two(int x) {
    x = subtract(x, 1);
    return subtract(x, 1);
}
