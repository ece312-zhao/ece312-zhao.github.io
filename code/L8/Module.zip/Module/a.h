#define NUM 10
