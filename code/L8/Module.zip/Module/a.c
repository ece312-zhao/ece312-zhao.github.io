#include "a.h"
#include "b.h"

int subtract_two(int x); // a function defined in c.c

int main() {
    int x = 0;

    x += NUM;

    x = subtract(x, 1);
    x = subtract_two(x);

    return x;
}
