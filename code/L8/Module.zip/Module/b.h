extern int a; // declare an "external" global variable

int subtract(int x, int dec); // declare a function
