#include "b.h"

int a = 0; // define the global variable

int subtract(int x, int dec) {
    return x - dec;
}
