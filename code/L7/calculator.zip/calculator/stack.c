#include "stack.h"

size_t n_pop, n_push;

static size_t internal_cnt;

Stack *stackAlloc() {
    const size_t init_sz = 16;

    Stack *stack = malloc(sizeof(*stack));
    if (!stack) {
        return NULL;
    }

    stack->_store = calloc(init_sz, sizeof(double));
    if (!stack->_store) {
        free(stack);
        return NULL;
    }

    stack->_cap = init_sz;
    stack->sz = 0;
    return stack;
}

void stackFree(Stack *this) {
    if (!this) return;

    free(this->_store);
    free(this);
}

double stackPop(Stack *this) {
    assert(this && this->sz > 0);
    this->sz -= 1;
    n_pop += 1;
    return this->_store[this->sz];
}

bool stackPush(Stack *this, double val) {
    assert(this);
    if (this->sz >= this->_cap) {
        const size_t scale = 2;
        if (this->_cap > SIZE_MAX / sizeof(double) / scale) {
            return false;
        }
        size_t new_cap = this->_cap * scale;

        double *new_store = realloc(this->_store, sizeof(double) * new_cap);
        if (!new_store) {
            return false;
        }
        this->_store = new_store;
        this->_cap = new_cap;
    }
    n_push += 1;
    this->_store[this->sz] = val;
    this->sz += 1;
    return true;
}
