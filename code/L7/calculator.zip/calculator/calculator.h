#pragma once

#include "stack.h"

int do_calculation(Stack *stack, int argc, char **argv);
