#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <assert.h>

#include "stack.h"
#include "calculator.h"

int do_calculation(Stack *stack, int argc, char **argv) {
    int ret = 0;
    for (size_t i = 1; i < argc; i++) {
        if (strlen(argv[i]) == 1 && (argv[i][0] == '+' || argv[i][0] == '-' ||
                                     argv[i][0] == '*' || argv[i][0] == '/')) {
            // We are dealing with an operator
            if (stack->sz < 2) {
                printf("Insufficient numbers on the stack!\n");
                ret = 1;
                goto err;
            }

            double right = stackPop(stack), left = stackPop(stack), res;
            switch (argv[i][0]) {
                case '+': {
                    res = left + right;
                    break;
                }
                case '-': {
                    res = left - right;
                    break;
                }
                case '/': {
                    res = left / right;
                    break;
                }
                case '*': {
                    res = left * right;
                    break;
                }
                default: {
                    assert(false && "Illegal operator!");
                }
            }
            if (!stackPush(stack, res)) {
                printf("Out of memory\n");
                ret = 1;
                goto err;
            }
        } else {
            char *end;
            double num = strtod(argv[i], &end);
            if (argv[i] == end || *end != '\0') {
                printf("Failed to parse number \"%s\"\n", argv[i]);
                ret = 1;
                goto err;
            }

            if (!stackPush(stack, num)) {
                printf("Out of memory\n");
                ret = 1;
                goto err;
            }
        }
    }

    if (stack->sz != 1) {
        printf("Stack has zero or multiple values remaining!\n");
        ret = 1;
        goto err;
    }

    printf("%f\n", stackPop(stack));

err:
    return ret;
}
