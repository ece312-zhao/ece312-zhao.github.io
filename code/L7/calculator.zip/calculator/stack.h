#ifndef STACK_H
#define STACK_H

#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <assert.h>

typedef struct {
    double *_store;
    size_t _cap, sz;
} Stack;

Stack *stackAlloc();

void stackFree(Stack *s);

double stackPop(Stack *s);

bool stackPush(Stack *s, double val);

extern size_t n_pop, n_push;

#endif // STACK_H
