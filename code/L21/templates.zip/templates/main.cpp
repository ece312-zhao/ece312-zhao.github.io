#include <cstdio>
#include "a.h"

int main() {
    int x = 10, y = 20;

    printf("max_int: %d\n", max_int(x, y));
    printf("max<int>: %d\n", max<int>(x, y));
}
