#include "a.h"

// Define the ordinary function here
int max_int(int x, int y) {
    if (x < y) {
        return y;
    } else {
        return x;
    }
}

#ifdef BUGGY
template <typename T>
T max(T x, T y) {
    if (x < y) {
        return y;
    } else {
        return x;
    }
}
#endif
