#pragma once

// We declare ordinary non-template functions in the header file
// and usually define them in a .cpp file.
int max_int(int x, int y);

// Function templates are different.
// The compiler needs to see the full template definition
// to instantiate the template.
//
// If we only put the declaration here (like the one under BUGGY)
// and move the definition to a.cpp, then main.cpp can see that
// max<T> exists, but when it tries to use max<int>, it does not
// see the function body needed to instantiate max<int>.
//
// Meanwhile, a.cpp contains the template definition, but in this example
// it does not use max<int>, so that file does not generate code for
// max<int> either.
//
// As a result, no object file provides the compiled code for max<int>,
// so the linker reports an error.
//
// Therefore, function templates are usually defined in header files.
//
// Use: g++ *.cpp -DBUGGY
// to see what happens when the template is only declared here.
#ifdef BUGGY
template <typename T>
T max(T x, T y); // Declaration only. Can lead to a link error.
#else
template <typename T>
T max(T x, T y) {
    if (x < y) {
        return y;
    } else {
        return x;
    }
}
#endif
